interface Empilhavel {



    fun desempilhar(): Any?
    fun estaVazia(): Boolean



}





